﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Beadando__urhajo_
{
    class Kapu:UrbazisElem
    {
        int sor, oszlop;

        public Kapu(int sor, int oszlop) : base(sor, oszlop)
        {
        }

        public override string ToString()
        {
            Console.BackgroundColor = ConsoleColor.Red;
            return "  ";
        }
    }
}
