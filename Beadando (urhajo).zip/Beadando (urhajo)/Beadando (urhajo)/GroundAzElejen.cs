﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Beadando__urhajo_
{
    class GroundAzElejen:UrbazisElem
    {
        public GroundAzElejen(int sor, int oszlop) : base(sor, oszlop)
        {
        }

        public override string ToString()
        {
            Console.BackgroundColor = ConsoleColor.Cyan;
            return "  ";
        }
    }
}
