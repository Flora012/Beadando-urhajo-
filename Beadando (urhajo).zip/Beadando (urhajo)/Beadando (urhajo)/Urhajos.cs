﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Beadando__urhajo_
{
     class Urhajos:UrbazisElem
    {
        Random r = new Random();
        int sor, oszlop;
        public int elet=100;

        public Urhajos(int sor, int oszlop) : base(sor, oszlop)
        {
        }

        

        public override string ToString()
        {
            Console.BackgroundColor = ConsoleColor.DarkYellow;
            return "  ";
        }
    }
}
