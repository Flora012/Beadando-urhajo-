﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Beadando__urhajo_
{
    class Robot:UrbazisElem
    {
        int sor, oszlop;
        public int elet, ero;

        public Robot(int sor, int oszlop) : base(sor, oszlop)
        {
        }
        public void eroBekeres(int bekertero)
        {
            ero = bekertero;
        }

        public override string ToString()
        {
            Console.BackgroundColor = ConsoleColor.White;
            return "  ";
        }
    }
}
