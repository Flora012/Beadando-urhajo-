﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Beadando__urhajo_
{
    abstract class UrbazisElem
    {
        public int sorUE, oszlopUE;

        protected UrbazisElem(int sor, int oszlop)
        {
            sorUE = sor;
            oszlopUE = oszlop;
        }
    }
}
