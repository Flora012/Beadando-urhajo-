﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Threading;
using System.Web;

namespace Beadando__urhajo_
{
    class Urbazis
    {
        public UrbazisElem[,] aPalya = new UrbazisElem[20, 20];
        int robotElet, urhajosElet, urhajosEro;
        List<int> robotEro = new List<int>();
        List<Type> valasztasOsztalyok = new List<Type> { typeof(Mars), typeof(Uzemanyag), typeof(Robot), typeof(SzuperAlien), typeof(Urhajos) };
        List<int> valasztasHany = new List<int> { 4, 3, 4, 1, 1 };
        int[,] sutiTarolas = new int[4, 2] { { -1, -1 }, { -1, -1 }, { -1, -1 }, { -1, -1 } };
        int kannaSzamlalo = 0;
        int hanysuti = 0;
        int hanysutimegtalalt = 0;

        UrbazisElem[,] aPalyaJatekAlatt = new UrbazisElem[20, 20];

        int[,] koordinatakSzinezeshez = new int[8, 2] { { -1, -1 }, { -1, 0 }, { -1, 1 }, { 0, 1 }, { 1, 1 }, { 1, 0 }, { 1, -1 }, { 0, -1 } };
        int[,] koordinatakSzinezeshezellentet = new int[8, 2] { { 1, 1 }, { 1, 0 }, { 1, -1 }, { 0, -1 }, { -1, -1 }, { -1, 0 }, { -1, 1 }, { 0, 1 } };
        int[,] koordinatakAzUrhajosKorul = new int[8, 2];

        int urhajosElsoKoordinata = 0;
        int urhajosMasodikKoordinata = 0;

        int kapuElsoKoordinata = 0;
        int kapuMasodikKoordinata = 0;

        List<int> hatmegnemtudom;

        int[,] aPalyaSzele = new int[76, 2];

        public void feltolt()
        {

            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 20; j++)
                {

                    aPalya[i, j] = new Ground(i, j);
                    aPalyaJatekAlatt[i, j] = new GroundAzElejen(i, j);
                    if ((i == 0) || (j == 0) || i == 19 || j == 19)
                    {
                        aPalyaSzele[i, 0] = i;
                        aPalyaSzele[i, 1] = j;
                    }
                }
            }
        }

        public void feltoltElemekkel()
        {
            feltolt();
            Random r = new Random();
            for (int i = 0; i < 14; i++)
            {
                int egyR = r.Next(0, 20);
                int kettoR = r.Next(0, 20);
                int melyikR = r.Next(0, valasztasHany.Count);
                if (aPalya[egyR, kettoR] is Ground && valasztasOsztalyok.Count != 0)
                {
                    Type valasztottElemTipus = valasztasOsztalyok[melyikR];
                    UrbazisElem ujElem = (UrbazisElem)Activator.CreateInstance(valasztottElemTipus, egyR, kettoR);
                    aPalya[egyR, kettoR] = ujElem;
                    if (aPalya[egyR, kettoR] is Urhajos)
                    {
                        urhajosElsoKoordinata = egyR;
                        urhajosMasodikKoordinata = kettoR;
                        urhajosEro = r.Next(21, 35);
                        urhajosElet = 100;

                    }
                    if (aPalya[egyR, kettoR] is Kapu)
                    {
                        kapuElsoKoordinata = egyR;
                        kapuMasodikKoordinata = kettoR;
                    }
                    valasztasHany[melyikR] -= 1;
                    if (valasztasHany[melyikR] == 0)
                    {
                        valasztasHany.RemoveAt(melyikR);
                        valasztasOsztalyok.RemoveAt(melyikR);
                    }
                }
                if (!(aPalya[egyR, kettoR] is Ground))
                {
                    i--;
                }
            }
            int m = r.Next(0, 9);
            for (int i = 0; i < 4; i++)
            {
                robotEro.Add(r.Next(10, 19));
            }
            do
            {
                m = r.Next(0, 9);

            } while (!(aPalya[aPalyaSzele[m, 0], aPalyaSzele[m, 1]] is Ground));

            Console.WriteLine(urhajosElsoKoordinata + "   " + urhajosMasodikKoordinata);
            aPalya[aPalyaSzele[m, 0], aPalyaSzele[m, 1]] = new Kapu(aPalyaSzele[m, 0], aPalyaSzele[m, 1]);
            felfedezes();
            while (!(aPalya[urhajosElsoKoordinata,urhajosMasodikKoordinata] is Kapu))
            {
                Thread.Sleep(1000);
                ellenorizrobot();
                if (megtalaltEKapu())
                {
                    leptet(kapuElsoKoordinata, kapuMasodikKoordinata);
                }
                if (ellenorizElet())
                {
                    for (int l = 0; l < sutiTarolas.GetLength(0); l++)
                    {
                        if (sutiTarolas[l, 0] != -1)
                        {
                            leptet(sutiTarolas[l, 0], sutiTarolas[l, 1]);
                            break;
                        }
                    }

                }
                else
                {
                    hatmegnemtudom = MegkeresLegkozelebbiCel();
                    Console.WriteLine(hatmegnemtudom[0] + "    " + hatmegnemtudom[1]);
                    leptet(hatmegnemtudom[0], hatmegnemtudom[1]);

                }
            }
            
            
        }

        public bool ellenorizElet()
        {
            if(urhajosElet<50 && hanysuti != 0)
            {
                return true;
            }
            return false;
        }

        public bool megtalaltEKapu()
        {
            if (aPalyaJatekAlatt[kapuElsoKoordinata,kapuMasodikKoordinata] is Kapu && kannaSzamlalo == 3)
            {
                return true;
            }
            return false;
            
        }

        public void felfedezes()
        {

            aPalyaJatekAlatt[urhajosElsoKoordinata, urhajosMasodikKoordinata] = aPalya[urhajosElsoKoordinata, urhajosMasodikKoordinata];

            for (int i = 0; i < koordinatakSzinezeshez.GetLength(0); i++)
            {
                koordinatakAzUrhajosKorul[i, 0] = urhajosElsoKoordinata + koordinatakSzinezeshez[i, 0];
                koordinatakAzUrhajosKorul[i, 1] = urhajosMasodikKoordinata + koordinatakSzinezeshez[i, 1];
                if (koordinatakAzUrhajosKorul[i, 0] < 20 && 0 <= koordinatakAzUrhajosKorul[i, 0] && koordinatakAzUrhajosKorul[i, 1] < 20 && 0 <= koordinatakAzUrhajosKorul[i, 1])
                {

                    aPalyaJatekAlatt[koordinatakAzUrhajosKorul[i, 0], koordinatakAzUrhajosKorul[i, 1]] = aPalya[urhajosElsoKoordinata + koordinatakSzinezeshez[i, 0], urhajosMasodikKoordinata + koordinatakSzinezeshez[i, 1]];
                }



            }

        }
        //public List<int> megkeresLegkozelebbi()
        //{



        //    for (int i = 0; i < aPalya.GetLength(0); i++)
        //    {
        //        if (koordinatakAzUrhajosKorul[i, 1] != -1 && koordinatakAzUrhajosKorul[i, 0] != -1 && aPalya[koordinatakAzUrhajosKorul[i, 0], koordinatakAzUrhajosKorul[i,1]]is Ground)
        //        {
        //            return new List<int>() { aPalya[koordinatakAzUrhajosKorul[i, 0], koordinatakAzUrhajosKorul[i, 1]].oszlopUE, aPalya[koordinatakAzUrhajosKorul[i, 0], koordinatakAzUrhajosKorul[i, 1]].sorUE };
        //        }

        //        if(aPalya)




        //    }
        //    return null;

        //}
        public void ellenorizrobot()
        {

            for (int i = 0; i < koordinatakAzUrhajosKorul.GetLength(0); i++)
            {
                if (koordinatakAzUrhajosKorul[i, 0] != 20 && koordinatakAzUrhajosKorul[i, 1] != 20&&koordinatakAzUrhajosKorul[i, 0]!=-1 && koordinatakAzUrhajosKorul[i, 1]!=-1 && aPalya[koordinatakAzUrhajosKorul[i, 0], koordinatakAzUrhajosKorul[i,1]] is Robot)
                {
                    harcol(koordinatakAzUrhajosKorul[i, 0], koordinatakAzUrhajosKorul[i, 1]);
                }
                if(aPalya[koordinatakAzUrhajosKorul[i, 0], koordinatakAzUrhajosKorul[i, 1]] is Uzemanyag)
                {
                    aPalya[koordinatakAzUrhajosKorul[i, 0], koordinatakAzUrhajosKorul[i, 1]] = new Ground(koordinatakAzUrhajosKorul[i, 0], koordinatakAzUrhajosKorul[i, 1]);
                    aPalyaJatekAlatt[koordinatakAzUrhajosKorul[i, 0], koordinatakAzUrhajosKorul[i, 1]] = aPalya[koordinatakAzUrhajosKorul[i, 0], koordinatakAzUrhajosKorul[i, 1]];
                    kannaSzamlalo++;
                    Console.WriteLine("Plusz egy kanna");
                }
                if(aPalya[koordinatakAzUrhajosKorul[i, 0], koordinatakAzUrhajosKorul[i, 1]] is Mars)
                {
                    for (int j = 0; j < sutiTarolas.GetLength(0); j++)
                    {
                        if (sutiTarolas[j, 0] == -1)
                        {
                            sutiTarolas[j, 0] = koordinatakAzUrhajosKorul[i, 0];
                            sutiTarolas[j, 1] = koordinatakAzUrhajosKorul[i, 1];
                            hanysuti++;
                            hanysutimegtalalt++;
                        }
                    }

                }
                
            }
        }

        public void harcol(int sor, int oszlop)
        {
            robotElet = 100;
            for (int i = 0; i < 30; i++)
            {
                if(robotElet>0 || urhajosElet > 0)
                {
                    robotElet -= urhajosEro;
                    urhajosElet -= robotEro[0];
                    Console.WriteLine("A robot elete:  " + robotElet);
                    Console.WriteLine("Az urhajos elete:  " + urhajosElet);
                }
                if (urhajosElet < 1)
                {
                    i = 30;
                }
                if (robotElet < 1)
                {
                    robotEro.Remove(0);
                    aPalya[sor, oszlop] = new Ground(sor, oszlop);
                    aPalyaJatekAlatt[sor, oszlop] = aPalya[sor, oszlop];
                    i = 30;
                }
            }
            
            
        }

        private List<int> MegkeresLegkozelebbiCel()
        {
            double legkisebbTavolsag = double.MaxValue;
            List<int> legkozelebbiCelIndex = new List<int>() { -1, -1 };


            for (int i = 0; i < aPalya.GetLength(0); i++)
            {
                for (int j = 0; j < aPalya.GetLength(1); j++)
                {

                    if (aPalyaJatekAlatt[i, j] is GroundAzElejen)
                    {
                        double tavolsag = Math.Sqrt(Math.Pow(urhajosElsoKoordinata - aPalya[i, j].sorUE, 2) + Math.Pow(urhajosMasodikKoordinata - aPalya[i, j].oszlopUE, 2));
                        if (tavolsag < legkisebbTavolsag)
                        {
                            legkisebbTavolsag = tavolsag;
                            legkozelebbiCelIndex[0] = i;
                            legkozelebbiCelIndex[1] = j;
                        }
                    }
                }


            }
            return legkozelebbiCelIndex;



        }
        public List<int> megkeresiLegkozelebbiGround()
        {
            for (int i = 0; i < aPalya.GetLength(0); i++)
            {
                for (int j = 0; j < aPalya.GetLength(1); j++)
                {
                    for (int k = 0; k < koordinatakSzinezeshez.GetLength(0); k++)
                    {
                        if (aPalya[i, j].sorUE + koordinatakSzinezeshez[k, 0] == aPalya[urhajosElsoKoordinata, urhajosMasodikKoordinata].sorUE
                        && aPalya[i, j].oszlopUE + koordinatakSzinezeshez[k, 1] == aPalya[urhajosElsoKoordinata, urhajosMasodikKoordinata].oszlopUE
                        && aPalya[i, j].sorUE + koordinatakSzinezeshez[k, 0] == aPalya[hatmegnemtudom[0], 0].sorUE
                        && aPalya[i, j].oszlopUE + koordinatakSzinezeshez[k, 1] == aPalya[hatmegnemtudom[1], 1].oszlopUE)
                        {
                            return new List<int> { i, j };
                        }
                        else if (!(aPalya[urhajosElsoKoordinata, urhajosMasodikKoordinata] is Ground) || !(aPalya[urhajosElsoKoordinata, urhajosMasodikKoordinata] is Ground) 
                            || !(aPalya[hatmegnemtudom[0], 0] is Ground) || !(aPalya[hatmegnemtudom[1], 1] is Ground))
                        {
                            if (i + 1 <= 19 && urhajosElsoKoordinata + 1<20&&aPalya[urhajosElsoKoordinata + 1, urhajosMasodikKoordinata] is Ground)
                            {
                                return new List<int> { urhajosElsoKoordinata + 1, urhajosMasodikKoordinata };
                            }
                            else if (j + 1 <= 19 && urhajosMasodikKoordinata + 1<20&&aPalya[urhajosElsoKoordinata, urhajosMasodikKoordinata + 1] is Ground)
                            {
                                return new List<int> { urhajosElsoKoordinata, urhajosMasodikKoordinata + 1 };
                            }
                            else if(j - 1 >= 0 && urhajosMasodikKoordinata - 1>-1&&aPalya[urhajosElsoKoordinata, urhajosMasodikKoordinata - 1] is Ground)
                            {
                                return new List<int> { urhajosElsoKoordinata, urhajosMasodikKoordinata - 1 };
                            }

                            else if (i - 1 >= 0 && urhajosElsoKoordinata - 1>-1&&aPalya[urhajosElsoKoordinata - 1, urhajosMasodikKoordinata] is Ground)
                            {
                                return new List<int> { urhajosElsoKoordinata - 1, urhajosMasodikKoordinata };
                            }
                        }


                    }

                }
            }
            return new List<int> { -1, -1 };
        }
        public List<int> hovaLepjen(int holoszlop, int holsor)
        {
            if (urhajosElsoKoordinata + holsor<20 && urhajosElsoKoordinata + holsor>-1 && urhajosMasodikKoordinata + holoszlop>-1&& urhajosMasodikKoordinata + holoszlop<20 && aPalya[urhajosElsoKoordinata + holsor, urhajosMasodikKoordinata + holoszlop] is Ground)
            {
                Thread.Sleep(1000);
                aPalya[urhajosElsoKoordinata + holsor, urhajosMasodikKoordinata + holoszlop] = new Urhajos(urhajosElsoKoordinata + holsor, urhajosMasodikKoordinata + holoszlop);
                return new List<int> { urhajosElsoKoordinata + holsor, urhajosMasodikKoordinata + holoszlop };
            }
            else
            {
                Thread.Sleep(1000);
                List<int> hovalepjenLista = megkeresiLegkozelebbiGround();
                aPalya[hovalepjenLista[0], hovalepjenLista[1]] = new Urhajos(hovalepjenLista[0], hovalepjenLista[1]);

                return new List<int> { hovalepjenLista[0], hovalepjenLista[1] };
            }
        }

        public void leptet(int egysor, int egyoszlop)
        {
            List<int> b = new List<int>();
            while (aPalya[egysor, egyoszlop] != aPalyaJatekAlatt[egysor, egyoszlop])
            {
                b = leptetIfek(egysor, egyoszlop);
                aPalya[urhajosElsoKoordinata, urhajosMasodikKoordinata] = new Ground(urhajosElsoKoordinata, urhajosMasodikKoordinata);

                Console.WriteLine("Hova megy:  "+egysor+"   "+egyoszlop);
                urhajosElsoKoordinata = b[0];
                urhajosMasodikKoordinata = b[1];
                Console.WriteLine("Hol van jelenleg: "+urhajosElsoKoordinata+"   "+urhajosMasodikKoordinata);
                aPalya[urhajosElsoKoordinata, urhajosMasodikKoordinata] = new Urhajos(urhajosElsoKoordinata, urhajosMasodikKoordinata);
                felfedezes();
                kiiratas();

            }
            if(aPalya[egysor, egyoszlop] is Mars)
            {
                hanysuti--;
                aPalya[egysor, egyoszlop] = new Ground(egysor, egyoszlop);
                aPalyaJatekAlatt[egysor, egyoszlop] = aPalya[egysor, egyoszlop];


            }
            
        }

        public List<int> leptetIfek(int egysor, int egyoszlop)
        {
            if (urhajosElsoKoordinata < aPalya[egysor, egyoszlop].sorUE && urhajosMasodikKoordinata < aPalya[egysor, egyoszlop].oszlopUE)
            {
                return hovaLepjen(1, 1);
            }
            else if (urhajosElsoKoordinata > aPalya[egysor, egyoszlop].sorUE && urhajosMasodikKoordinata > aPalya[egysor, egyoszlop].oszlopUE)
            {
                return hovaLepjen(-1, -1);
            }
            else if (urhajosElsoKoordinata > aPalya[egysor, egyoszlop].sorUE && urhajosMasodikKoordinata == aPalya[egysor, egyoszlop].oszlopUE)
            {
                return hovaLepjen(0,-1);
            }
            else if (urhajosElsoKoordinata == aPalya[egysor, egyoszlop].sorUE && urhajosMasodikKoordinata > aPalya[egysor, egyoszlop].oszlopUE)
            {
                return hovaLepjen(-1, 0);
            }
            else if (urhajosElsoKoordinata < aPalya[egysor, egyoszlop].sorUE && urhajosMasodikKoordinata == aPalya[egysor, egyoszlop].oszlopUE)
            {
                return hovaLepjen(0, 1);
            }
            else if (urhajosElsoKoordinata < aPalya[egysor, egyoszlop].sorUE && urhajosMasodikKoordinata > aPalya[egysor, egyoszlop].oszlopUE)
            {
                return hovaLepjen(1, 1);
            }
            else if (urhajosElsoKoordinata > aPalya[egysor, egyoszlop].sorUE && urhajosMasodikKoordinata < aPalya[egysor, egyoszlop].oszlopUE)
            {
                return hovaLepjen(1, 1);
            }
            else if (urhajosElsoKoordinata == aPalya[egysor, egyoszlop].sorUE && urhajosMasodikKoordinata < aPalya[egysor, egyoszlop].oszlopUE)
            {
                return hovaLepjen(1, 0);
            }
            return new List<int> { -1, -1 };
        }



        public void kiiratas()
        {

            Console.WriteLine("fffffffffffffffffffffffffffffffffffffffff");
            Console.WriteLine();

            for (int i = 0; i < aPalya.GetLength(0); i++)
            {
                for (int j = 0; j < aPalya.GetLength(1); j++)
                {

                    Console.Write(aPalyaJatekAlatt[i, j]);
                }
                Console.BackgroundColor = ConsoleColor.Black;
                Console.WriteLine();

            }
        }







    }
}