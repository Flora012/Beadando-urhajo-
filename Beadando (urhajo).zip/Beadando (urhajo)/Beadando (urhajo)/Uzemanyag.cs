﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Beadando__urhajo_
{
     class Uzemanyag:UrbazisElem
    {
        int sor, oszlop;

        public Uzemanyag(int sor, int oszlop) : base(sor, oszlop)
        {

        }

        public override string ToString()
        {
            Console.BackgroundColor = ConsoleColor.DarkGreen;
            return "  ";
        }
    }
}
